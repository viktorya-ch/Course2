package org.skypro.skyapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyapplicationApplication.class, args);
	}

}
